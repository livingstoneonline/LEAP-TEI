Sandbox were letters that being transcribed and had not been seen by Chris, possibly not read through
 
Staging area had been seen by Chris and those edits were done - possibly other coding isues to resolve 


